# v0.1.1

Fixed above ground floods spawning too low
Rebalanced minimum and maximum facility flooding levels

# v0.1.0

Fixed floods duplicating between levels
Rebalancing tweaks

# v0.0.1

Intial beta version