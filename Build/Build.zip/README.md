# OopsAllFlooded

Indoor flooding mod by [squirrelboydev](https://twitter.com/squirrelboydev).

Adds slowly rising water inside the facility during "Flooded" weather and sometimes during "Stormy" and "Rainy" weather.

Requires the latest version of BepInEX.